import scala.io.Source
import java.io._


object Generator extends App{
  if(args.length != 2){
    println("No input and/or output file provded. Exiting")
    System.exit(1)
  }
  val sourceFolder = new File(getClass.getClassLoader.getResource(args(0)).getPath)

  for( dataFile <- sourceFolder.listFiles){
    val input = Source.fromFile(dataFile)
    val output = new File(getClass.getClassLoader.getResource(args(1)).getPath+ "/" + dataFile.getName + ".dzn")
    println(input + " -> " + output)
    convertFile(input,output)
  }

  def convertFile(inputFile:Source ,outputFile:File) = {
    val bw = new BufferedWriter(new FileWriter(outputFile))
    val lines = inputFile.getLines
    val sizes = lines.next.split("\\s+").drop(1)

    val nColors = lines.next
    val nItems = lines.next

    val items = lines.toArray.map(_.split("\\s+"))
    
    bw.write("nItems = " + nItems + ";\n")
    bw.write("ITEMS = 1..nItems;\n")
    bw.write("BINS = 1..nItems;\n")
    bw.write("COLORS = 1.." + nColors + ";\n")
    bw.write("CAPACITIES = 1.."+sizes.length +";\n")
    bw.write("capacities = " + sizes.mkString("[",",","]") + ";\n")
    bw.write("size = " + items.map(_.apply(0)).mkString("[",",","]") + ";\n")
    bw.write("color = " + items.map(_.apply(1)).mkString("[",",","]") + ";\n")
    bw.close
  }
}
